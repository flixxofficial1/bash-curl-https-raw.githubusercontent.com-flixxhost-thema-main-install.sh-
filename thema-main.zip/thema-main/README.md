# Theme
JANGAN DIJUAL BELAKAN YE BWANG !!!
BUTUH LICENSE/PW CHAT TELE GUA
>> https://t.me/FlixxOfficiall

Comand Run Install Thema

bash <(curl https://raw.githubusercontent.com/FlixxOffc/thema/main/install.sh)
